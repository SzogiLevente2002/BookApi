﻿namespace BookWebApplicationAuth.Entities
{
    public class Author
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime BirthDate { get; set; }
        public string UserId { get; set; }
        
    }

}
